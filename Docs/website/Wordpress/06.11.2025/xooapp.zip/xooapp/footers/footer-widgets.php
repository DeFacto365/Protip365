
<div class="container">
	<div class="row footer-widget-area">
		<!-- Footer widget area -->
		<?php if( is_active_sidebar( 'footer-one' ) ) { ?>
			<?php dynamic_sidebar( 'footer-one' ); ?>
		<?php } ?>

		<!-- FOOTER INFO -->
	</div>
</div>
